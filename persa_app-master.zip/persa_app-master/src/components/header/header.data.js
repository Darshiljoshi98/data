export default [
  {
    path: 'home',
    label: 'Home',
  },
  {
    path: 'feature',
    label: 'Features',
  },
  {
    path: 'feedback',
    label: 'Feedback',
  },
  {
    path: 'support',
    label: 'Support',
  },
];
