# persa_app

Template built using NextJS

<a href="https://persa-app-git-master-xd-ob.vercel.app/">Live Demo here!</a>

## Owners
- **Belouche Oussama** 1337
- ** Elouargui Anas** 1337

#
[![forthebadge](https://forthebadge.com/images/badges/made-with-javascript.svg)](https://forthebadge.com)
