module.exports = {
  siteUrl: 'https://persa-app-hwm9vtt93.vercel.app/',
  generateRobotsTxt: true,
};
